compile all (*.java) then run 'IteratorPatternDemo'
