<?php
	function example_initialize() {
		//code that initializes an "example"
	}

	function example_finalize() {
		//code that destorys an "example"
	}

	function example_printString(s) {
		print(s);
	}
?>